<?php
session_start();
// if(!isset($_SESSION['username'])){
//     header('location:login.php');
//   }
include('includes/header.php');
include('admin_sidenavbar.php');
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>G_view profile</title>
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous"> -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <!-- <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700&display=swap');

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        .container {
            max-width: 700px;
            width: 100%;
            background-color: #fff;
            padding: 20px 30px;
            border-radius: 5px;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.15);
        }

        .img-fluid {
            height: 200px;
            width: 180px;
        }

        .profile-head {
            padding-top: 15px;
            padding-left: 20px;
        }

        .table {
            font-size: small;
        }

        .details,
        .table-dark {
            text-align: center;
        }
    </style> -->
</head>

<body>

    <div class="modal" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <?php
            require 'dbconnection.php';
            // $query = "SELECT * FROM `student` where email=";
            $query_run = mysqli_query($conn, "SELECT * FROM `student` where reg_no='" . $_SESSION['studentusername'] . "'");
            $count = mysqli_num_rows($query_run);
            ?>
            <div class="modal-content">
                <?php
                if ($count > 0) {
                    $idno = 0;
                    while ($row = mysqli_fetch_assoc($query_run)) {
                        $idno = $idno + 1;
                ?>
                        <div class="modal-header">
                            <h5 class="modal-title" id="staticBackdropLabel">> Complainant Details</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="profile-img">
                                        <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-profiles/avatar-1.webp" class="img-fluid img-thumbnail mt-4 mb-2">
                                    </div>
                                </div>
                                <div class="col-md-8 mt-5">
                                    <div class="profile-head">
                                        <table class="table table-borderless">
                                            <tr>
                                                <th scope="col" id="col">Name</th>
                                                <td>CHITTARANJAN</td>
                                            </tr>
                                            <tr>
                                                <th scope="col" id="col">Registration No.</th>
                                                <td></td>
                                            </tr>
                                            <tr>
                                                <th scope="col">Course</th>
                                                <td></td>
                                            </tr>
                                        </table>
                                    </div>
                                </div>
                            </div><br>
                            <div>
                                <table class="table table-striped table-bordered">
                                    <thead class="table-dark">
                                        <tr>
                                            <th scope="col">Branch</th>
                                            <th scope="col">Year</th>
                                            <th scope="col">Semester</th>
                                            <th scope="col">Contact</th>
                                            <th scope="col">e-mail</th>
                                        </tr>
                                    </thead>
                                    <tbody class="details">
                                        <tr>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                            <td></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                <?php
                    }
                }
                ?>
            </div>
        </div>
    </div>
</body>

</html>
<div class="container">
    <div class="content" style="margin-left:40% ;">
        <span style="font-weight:bolder; font-size:xxx-large;color:#000000;">Grivence History</span>
    </div>
</div>
<div class="content-wrapper">
    <!-- <div class="container-fluid"> -->
    <div class="container-fluid">
        <div class="card shadow mb-5">
            <div _ngcontent-sow-c12="" class="card-body">

                <div class="card-header py-3 mb-2" style="background-color: #123456;">
                    <h6 class="m-4 font-weight-bold text-primary"><span style="font-weight:bolder; font-size:x-large;color:#7FFFD4;">All Complaints</span> </h6>
                </div>
                <div _ngcontent-sow-c12="" class="table-responsive">
                    <table _ngcontent-sow-c12="" class="table table-bordered" width="100%" cellspacing="0" id="myTable">
                        <?php
                        require 'dbconnection.php';
                        $query = "SELECT * FROM `grivence_register`";
                        $query_run = mysqli_query($conn, $query);
                        $num_query = mysqli_num_rows($query_run);

                        ?>
                        <thead _ngcontent-sow-c12="" class="thead-light">
                            <tr _ngcontent-sow-c12="">
                                <td _ngcontent-sow-c12="">STUDENT_ID</td>
                                <td _ngcontent-sow-c12="">TAG</td>
                                <td _ngcontent-sow-c12="">GRIVENCE_TYPE</td>
                                <td _ngcontent-sow-c12="">NOG</td>
                                <td _ngcontent-sow-c12="">REG_TIME</td>
                                <!-- <td _ngcontent-sow-c12="">UPDATE_TIME</td> -->



                                <td _ngcontent-sow-c12="">Status</td>
                                <td _ngcontent-sow-c12="">DETAILS</td>

                            </tr>
                        </thead>
                        <tbody _ngcontent-sow-c12="">
                            <?php
                            if ($num_query > 0) {
                                while ($row = mysqli_fetch_assoc($query_run)) {
                            ?>
                                    <tr _ngcontent-sow-c12="">
                                        <td _ngcontent-sow-c12="">
                                            <form action="#" method="post">
                                                <input type="hidden" value="<?php echo $row['student_id']; ?>" name="viewuprofile">
                                                <button type="submit" name="viewcomplaintuserprofile" class="btn btn-link"> <a data-bs-toggle="modal" href="#staticBackdrop ">
                                                <?php echo $row['student_id']; ?>
                                                    </a></button>
                                            </form>

                                        </td>
                                        <td _ngcontent-sow-c12=""><?php echo $row['dean_type']; ?></td>
                                        <td _ngcontent-sow-c12=""><?php echo $row['grivence_type']; ?></td>
                                        <td _ngcontent-sow-c12=""><?php echo $row['noc']; ?></td>
                                        <td _ngcontent-sow-c12=""><?php echo $row['register_date']; ?></td>
                                        <!-- <td _ngcontent-sow-c12=""><?php echo $row['update_date']; ?></td> -->

                                        <td _ngcontent-sow-c12="">
                                            <?php
                                            if ($row['status'] == "closed") {
                                                echo '<p class="btn btn-success">' . $row['status'] . '</p>';
                                            } else if ($row['status'] == "inprogress") {
                                                echo '<p class="btn btn-info">' . $row['status'] . '</p>';
                                            } else {
                                                echo '<p class="btn btn-danger">Pending</p>';
                                            }

                                            ?>
                                        </td>
                                        <td _ngcontent-sow-c12="">
                                            <form action="#" method="post">
                                                <input type="hidden" value="<?php echo $row['complaint_no']; ?>" name="viewcoid">
                                                <button type="submit" name="complaintviewbyadmin" class="btn btn-primary">view</button>
                                            </form>
                                        </td>

                                    </tr>
                            <?php
                                }
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>


<?php
include('includes/script.php');


?>