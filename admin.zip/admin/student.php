<?php
session_start();
// if(!isset($_SESSION['username'])){
//     header('location:login.php');
//   }
include('includes/header.php');
include('includes/dean_sidenavabr.php');
?>
<!-- <div class="container-fluid"> -->
<div class="container">
    <div class="content" style="margin-left:35vh ;">
        <span style="font-weight:bolder; font-size:xxx-large;color:#000000;">Student Profiles</span>
    </div>
</div>
<div class="content-wrapper">
    <div class="container-fluid">
        <div class="card shadow mb-5">
            <div class="card-header py-3" style="background-color: #123456;">
                <h6 class="m-4 font-weight-bold text-primary"><span style="font-weight:bolder; font-size:x-large;color:#7FFFD4;">B.TECH</span> </h6>
            </div>
            <div class="card-body">
                <table class="table table-bordered" width="100%" cellspacing="0" id="myTable">
                    <?php
                    require 'dbconnection.php';
                    $query = "SELECT * FROM `student`";
                    $query_run = mysqli_query($conn, $query);
                    $num_query = mysqli_num_rows($query_run);

                    ?>
                    <thead>
                        <tr>
                            <td>ID</td>
                            <td>Image</td>
                            <td>Name</td>
                            <td>Registration_no</td>
                            <td>Department</td>
                            <td>Ustertype</td>
                            <td>View</td>
                            <td>Status</td>
                            <td>Delete</td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if ($num_query > 0) {
                            while ($row = mysqli_fetch_assoc($query_run)) {
                        ?>

                                <tr>
                                    <td><?php echo $row['id']; ?></td>
                                    <td><?php echo  '<img src="studentimage/' . $row['image'] . '" alt="" height="50px" width="50px" style="border-radius:50% ;">' ?></td>
                                    <td><?php echo $row['name']; ?></td>
                                    <td><?php echo $row['reg_no']; ?></td>
                                    <td><?php echo $row['department']; ?></td>
                                    <td><?php echo $row['usertype']; ?></td>
                                    <td>
                                    <form action="studentprofile.php" method="POST">
                                            <input type="hidden" name="viewid" value="<?php echo $row['id']; ?>">
                                            <button type="submit" name="viewstudent" class="btn btn-primary">view</button>
                                        </form>
                                    </td>
                                    <td>
                                    <?php if($row['status']=="active"){
                                                echo '<p class="btn btn-success">'.$row['status'].'</p>';
                                            }else
                                            echo '<p class="btn btn-danger">'.$row['status'].'</p>';
                                            ?>
                                    </td>
                                    <td>
                                        <form action="code.php" method="POST">
                                            <input type="hidden" name="deleteid" value="<?php echo $row['id']; ?>">
                                            <button type="submit" name="deletestudent" class="btn btn-danger">DELETE</button>
                                        </form>
                                    </td>
                                </tr>
                        <?php
                            }
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- </div> -->


<?php
include('includes/script.php');


?>