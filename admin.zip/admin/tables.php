<?php
session_start();
// if(!isset($_SESSION['username'])){
//     header('location:login.php');
//   }

include('includes/header.php');
include('admin_sidenavbar.php');

?>
<div class="content-wrapper">
    <div _ngcontent-lre-c12="" class="card mb-3">
        <div _ngcontent-lre-c12="" class="card-body">
            
            <h3 _ngcontent-lre-c12="" style="background-color: #123456;" class="card-header py-4 section-title mb-3 "><span style="font-weight:bolder; font-size:x-large;color:#7FFFD4;">B.TECH</span></h3>
          
            <div _ngcontent-lre-c12="" class="table-responsive">
                <table _ngcontent-lre-c12="" class="table table-sm table-bordered" id="myTable">
                    <thead _ngcontent-lre-c12="" class="thead-light">
                        <tr _ngcontent-lre-c12="">
                            <th _ngcontent-lre-c12="">Sl.#</th>
                            <th _ngcontent-lre-c12="">Academic Year</th>
                            <th _ngcontent-lre-c12="">Department Name</th>
                            <th _ngcontent-lre-c12="">Scheme Name</th>
                            <th _ngcontent-lre-c12="">Institute/School Name</th>
                            <th _ngcontent-lre-c12="">Application No.</th>
                            <th _ngcontent-lre-c12="">Type</th>
                            <th _ngcontent-lre-c12="">Apply Date</th>
                            <th _ngcontent-lre-c12="">Status</th>
                            <th _ngcontent-lre-c12="">Remark</th>
                            <th _ngcontent-lre-c12="" >Action</th>
                        </tr>
                    </thead>
                    <tbody _ngcontent-lre-c12="">
                        
                        <tr _ngcontent-lre-c12="">
                            <td _ngcontent-lre-c12="">1</td>
                            <td _ngcontent-lre-c12="">2022-23</td>
                            <td _ngcontent-lre-c12="">ST&amp;SC and MBC Welfare Department</td>
                            <td _ngcontent-lre-c12="">Post Matric Scholarship</td>
                            <td _ngcontent-lre-c12="">Gandhi Institute for Education and Technology, Khurda</td>
                            <td _ngcontent-lre-c12="">STSC92210191905918</td>
                            <td _ngcontent-lre-c12="">Renew in Same Course</td>
                            <td _ngcontent-lre-c12="">19-Oct-2022</td>
                            <td _ngcontent-lre-c12="">
                                <p _ngcontent-lre-c12="" class="m-0">
                                    Re-applied by Student
                                  
                                </p>
                            </td>
                            <td _ngcontent-lre-c12="">
                                
                            </td>
                            <td _ngcontent-lre-c12="">
                               <button _ngcontent-lre-c12="" color="success" mdbbtn="" mdbwaveseffect="" size="sm" title="View Details" type="button" class="btn btn-success btn-sm">View</button>
                                
                            </td>
                        </tr>
                       
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php
include('includes/script.php');


?>