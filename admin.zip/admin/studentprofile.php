<?php
session_start();
// if(!isset($_SESSION['username'])){
//     header('location:login.php');
//   }

include('includes/header.php');
include('includes/admin_sidenavbar.php');
?>
<!-- <div class="content-wrapper"> -->
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>v_profile</title>
    <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous"> -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <style>
        .container-fluid {
            padding-left: 300px;
            padding-right: 300px;
        }

        .profile-img {
            padding-left: 50px;

        }

        .profile-head {
            font-size: medium;
            padding-top: 15px;
        }

        .col {
            padding-left: 50px;
            padding-right: 50px;
        }

        .table {
            font-size: small;
        }
    </style>
</head>

<body>

    <div class="container-fluid ml-5">
        <div class="card mt-3 mb-3">
            <?php
            require 'dbconnection.php';
            if (isset($_POST['viewstudent'])) {
                $ids = $_POST['viewid'];

                $query = "SELECT * FROM `student` WHERE id='$ids'";
                $query_run = mysqli_query($conn, $query);
                foreach ($query_run as $row) {
            ?>

                    <div class="row">   
                        <div class="col-md-4">
                            <div class="profile-img">
                               <?php echo '<img src="studentimage/' . $row['image'] . '" class="img-fluid img-thumbnail mt-4 mb-2" width="100px" height="100px">'?>
                            </div>
                            <form action="student_update.php" method="post">
                                <input type="hidden" value="<?php echo $row['id']; ?>" name="editid">
                                <button type="submit" class="btn btn-info ml-5" name="editstudent" >Edit Student</button>
                            </form>
                        </div>
                        <div class="col-md-8 mt-4">
                            <div class="profile-head">
                                <b>Name :</b> <?php echo $row['name']; ?>  <br>
                                <b>Course :</b> <?php echo $row['stream']; ?> <br>
                                <b>Batch :</b> 2019-23 <br>
                                <b>Year :</b> 3rd <br>
                                <b>Semester :</b> 7th
                            </div>
                        </div>
                    </div><br>
                    <div class="row">
                        <div class="col">
                            <nav>
                                <div class="nav nav-tabs" id="nav-tab" role="tablist">
                                    <button class="nav-link active" id="nav-general-tab" data-bs-toggle="tab" data-bs-target="#nav-general" type="button" role="tab" aria-controls="nav-general" aria-selected="true">General Details</button>
                                    <button class="nav-link" id="nav-contact-tab" data-bs-toggle="tab" data-bs-target="#nav-contact" type="button" role="tab" aria-controls="nav-contact" aria-selected="true">Contact Details</button>
                                    <button class="nav-link" id="nav-postal-tab" data-bs-toggle="tab" data-bs-target="#nav-postal" type="button" role="tab" aria-controls="nav-postal" aria-selected="false">Postal Details</button>
                                    <button class="nav-link" id="nav-parents-tab" data-bs-toggle="tab" data-bs-target="#nav-parents" type="button" role="tab" aria-controls="nav-parents" aria-selected="false">Parent's Details</button>
                                </div>
                            </nav>
                            <div class="tab-content" id="nav-tabContent">
                                <div class="tab-pane fade show active" id="nav-general" role="tabpanel" aria-labelledby="nav-general-tab">
                                    <br>
                                    <table class="table table-striped table-bordered">
                                        <tbody>
                                            <tr>
                                                <th scope="col" id="col">Admission Date</th>
                                                <td><?php echo $row['admission_date']; ?></td>
                                            </tr>
                                            <tr>
                                                <th scope="col" id="col">Registration No.</th>
                                                <td><?php echo $row['reg_no']; ?></td>
                                            </tr>
                                            <tr>
                                                <th scope="col" id="col">Date of Birth</th>
                                                <td><?php echo $row['dob']; ?></td>
                                            </tr>
                                            <tr>
                                                <th scope="col" id="col">Blood Group</th>
                                                <td><?php echo $row['blod_group']; ?></td>
                                            </tr>
                                            <tr>
                                                <th scope="col" id="col">Gender</th>
                                                <td><?php echo $row['gender']; ?></td>
                                            </tr>
                                            <tr>
                                                <th scope="col" id="col">Nationality</th>
                                                <td><?php echo $row['nationality']; ?></td>
                                            </tr>
                                            <tr>
                                                <th scope="col" id="col">Mother Tounge</th>
                                                <td><?php echo $row['mothertounge']; ?></td>
                                            </tr>
                                            <tr>
                                                <th scope="col" id="col">Caste Category</th>
                                                <td><?php echo $row['cast']; ?></td>
                                            </tr>
                                            <tr>
                                                <th scope="col" id="col">Religion</th>
                                                <td><?php echo $row['religion']; ?></td>
                                            </tr>
                                            <tr>
                                                <th scope="col" id="col">Aadhaar Number</th>
                                                <td><?php echo $row['adhar_no']; ?></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="tab-pane fade" id="nav-contact" role="tabpanel" aria-labelledby="nav-contact-tab">
                                    <br>
                                    <table class="table table-striped table-bordered">
                                        <tbody>
                                            <tr>
                                                <th scope="col" id="col">Phone</th>
                                                <td><?php echo $row['contact_no']; ?></td>
                                            </tr>
                                            <tr>
                                                <th scope="col" id="col">Mobile</th>
                                                <td><?php echo $row['contact_no']; ?></td>
                                            </tr>
                                            <tr>
                                                <th scope="col" id="col">E-mail</th>
                                                <td><?php echo $row['email']; ?></td>
                                            </tr>
                                            <tr>
                                                <th scope="col" id="col">Father's Contact</th>
                                                <td><?php echo $row['father_contact_no']; ?></td>
                                            </tr>
                                            <tr>
                                                <th scope="col" id="col">Mother's Contact</th>
                                                <td><?php echo $row['mother_contact_no']; ?></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="tab-pane fade" id="nav-postal" role="tabpanel" aria-labelledby="nav-postal-tab">
                                    <br>
                                    <table class="table table-striped table-bordered">
                                        <tbody>
                                            <tr>
                                                <th scope="col" id="col">Address</th>
                                                <td><?php echo $row['adress']; ?></td>
                                            </tr>
                                            <tr>
                                                <th scope="col" id="col">City</th>
                                                <td><?php echo $row['city']; ?></td>
                                            </tr>
                                            <tr>
                                                <th scope="col" id="col">State</th>
                                                <td><?php echo $row['state']; ?></td>
                                            </tr>
                                            <tr>
                                                <th scope="col" id="col">PIN Code</th>
                                                <td><?php echo $row['pincode']; ?></td>
                                            </tr>
                                            <tr>
                                                <th scope="col" id="col">Country</th>
                                                <td><?php echo $row['country']; ?></td>
                                            </tr>
                                            <tr>
                                                <th scope="col" id="col">Birth Place</th>
                                                <td><?php echo $row['birth_place']; ?></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="tab-pane fade" id="nav-parents" role="tabpanel" aria-labelledby="nav-parents-tab">
                                    <br>
                                    <table class="table table-striped table-bordered">
                                        <tbody>
                                            <tr>
                                                <th scope="col" id="col">Father's Name</th>
                                                <td><?php echo $row['father_name']; ?></td>
                                            </tr>
                                            <tr>
                                                <th scope="col" id="col">Father's Qualification</th>
                                                <td><?php echo $row['father_qualification']; ?></td>
                                            </tr>
                                            <tr>
                                                <th scope="col" id="col">Father's Occupation</th>
                                                <td><?php echo $row['father_occupation']; ?></td>
                                            </tr>
                                            <tr>
                                                <th scope="col" id="col">Mother's Name</th>
                                                <td><?php echo $row['mother_name']; ?></td>
                                            </tr>
                                            <tr>
                                                <th scope="col" id="col">Mother's Qualification</th>
                                                <td><?php echo $row['mother_qualification']; ?></td>
                                            </tr>
                                            <tr>
                                                <th scope="col" id="col">Mother's Occupation</th>
                                                <td><?php echo $row['mother_occupation']; ?></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
        </div>
<?php
                }
            }
?>
    </div>
</body>

</html>

<!-- </div> -->

<?php
include('includes/script.php');


?>