<?php
$conn = mysqli_connect("localhost","root","","eims2");

?>
 