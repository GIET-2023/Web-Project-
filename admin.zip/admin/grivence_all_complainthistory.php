<?php
session_start();
// if(!isset($_SESSION['username'])){
//     header('location:login.php');
//   }
include('includes/header.php');
include('includes/admin_sidenavbar.php');
?>
<!-- modal -->


<!-- end modal -->
<div class="container">
    <div class="content" style="margin-left:40% ;">
        <span style="font-weight:bolder; font-size:xxx-large;color:#000000;">Grivence History</span>
    </div>
</div>
<div class="content-wrapper">
    <!-- <div class="container-fluid"> -->
    <div class="container-fluid">
        <div class="card shadow mb-5">
            <div _ngcontent-sow-c12="" class="card-body">

                <div class="card-header py-3 mb-2" style="background-color: #123456;">
                    <h6 class="m-4 font-weight-bold text-primary"><span style="font-weight:bolder; font-size:x-large;color:#7FFFD4;">All Complaints</span> </h6>
                </div>
                <div _ngcontent-sow-c12="" class="table-responsive">
                    <table _ngcontent-sow-c12="" class="table table-bordered" width="100%" cellspacing="0" id="myTable">
                        <?php
                        require 'dbconnection.php';
                        $query = "SELECT * FROM `grivence_register`";
                        $query_run = mysqli_query($conn, $query);
                        $num_query = mysqli_num_rows($query_run);

                        ?>
                        <thead _ngcontent-sow-c12="" class="thead-light">
                            <tr _ngcontent-sow-c12="">
                                <td _ngcontent-sow-c12="">STUDENT_ID</td>
                                <td _ngcontent-sow-c12="">TAG</td>
                                <td _ngcontent-sow-c12="">GRIVENCE_TYPE</td>
                                <td _ngcontent-sow-c12="">NOG</td>
                                <td _ngcontent-sow-c12="">REG_TIME</td>
                                <!-- <td _ngcontent-sow-c12="">UPDATE_TIME</td> -->



                                <td _ngcontent-sow-c12="">Status</td>
                                <td _ngcontent-sow-c12="">DETAILS</td>

                            </tr>
                        </thead>
                        <tbody _ngcontent-sow-c12="">
                            <?php
                            if ($num_query > 0) {
                                while ($row = mysqli_fetch_assoc($query_run)) {
                            ?>
                                    <tr _ngcontent-sow-c12="">
                                        <td _ngcontent-sow-c12="">
                                            <form action="grivrnce_student_profilr.php" method="POST" >
                                                <input type="hidden" value="<?php echo $row['student_id']; ?>" name="viewuprofile">
                                                <button type="submit" name="viewcomplaintuserprofile" class="btn btn-link"><?php echo $row['student_id']; ?></button>
                                            </form>

                                        </td>
                                        <td _ngcontent-sow-c12=""><?php echo $row['dean_type']; ?></td>
                                        <td _ngcontent-sow-c12=""><?php echo $row['grivence_type']; ?></td>
                                        <td _ngcontent-sow-c12=""><?php echo $row['noc']; ?></td>
                                        <td _ngcontent-sow-c12=""><?php echo $row['register_date']; ?></td>
                                        <!-- <td _ngcontent-sow-c12=""><?php echo $row['update_date']; ?></td> -->

                                        <td _ngcontent-sow-c12="">
                                            <?php
                                            if ($row['status'] == "closed") {
                                                echo '<p class="btn btn-success">' . $row['status'] . '</p>';
                                            } else if ($row['status'] == "inprogress") {
                                                echo '<p class="btn btn-info">' . $row['status'] . '</p>';
                                            } else {
                                                echo '<p class="btn btn-danger">Pending</p>';
                                            }

                                            ?>
                                        </td>
                                        <td _ngcontent-sow-c12="">
                                            <form action="#" method="post">
                                                <input type="hidden" value="<?php echo $row['complaint_no']; ?>" name="viewcoid">
                                                <button type="submit" name="complaintviewbyadmin" class="btn btn-primary">view</button>
                                            </form>
                                        </td>

                                    </tr>
                            <?php
                                }
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- </div> -->


<?php
include('includes/script.php');


?>