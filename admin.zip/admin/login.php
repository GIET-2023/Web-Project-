<?php
session_start();


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>loginform</title>
    <link rel="shortcut icon" type="image" href="logo.jpg">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
</head>

<body>

    
    <h2> Sign in/up Form</h2>
    <div class="container" id="container">

        <div class="form-container sign-in-container">
            <form action="code.php" method="POST">

                <h1>Sign in</h1>

                <div class="social-container">
                    <a href="#" class="social"><i class="fab fa-facebook-f"></i></a>
                    <a href="#" class="social"><i class="fab fa-google-plus-g"></i></a>
                    <a href="#" class="social"><i class="fab fa-linkedin-in"></i></a>
                </div>
                <span>or use your account</span>
                <input type="text" placeholder="Enter your username" name="loginusername" require />
                <input type="password" placeholder="Password" name="loginpassword" require />
                <a href="#">Forgot your password?</a>
                <button name="login" type="submit">Log In</button>
            </form>
        </div>
        <div class="overlay-container">
            <div class="overlay">
                <div class="overlay-panel overlay-left">
                    <h1>Welcome Back!</h1>
                    <p>To keep connected with us please login with your personal info</p>
                    <button class="ghost" id="signIn">Sign In</button>
                </div>
                <div class="overlay-panel overlay-right">
                    <img src="giet1.png" alt="">
                    <h1>Welcome Rajesh!</h1>
                    <p>To keep connected with us please login with your personal info</p>
                    <a href="signup.php"><button class="ghost" id="signUp">Sign Up</button></a>
                </div>
            </div>
        </div>
    </div>

    <footer>
        <p>
            Created with <i class="fa fa-heart"></i> by
            <a target="_blank" href="#">Rajesh</a>
            - Read how I created this and how you can join the challenge
            <a target="_blank" href="#">here</a>.
        </p>
    </footer>
    <script src="script.js"></script>
</body>

</html>