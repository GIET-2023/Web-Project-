<?php
session_start();
if(!isset($_SESSION['studentusername'])){
  header('location:login.php');
}
include('includes/header.php');
include('includes/dean_sidenavabr.php');
?>

<?php

include('includes/script.php');

?>