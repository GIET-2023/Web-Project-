<?php
session_start();
// if(!isset($_SESSION['username'])){
//     header('location:login.php');
//   }
include('includes/header.php');
include('includes/dean_sidenavabr.php');
?>
<div class="content-wrapper">
    <!DOCTYPE html>
    <html lang="en">
    <?php
    require 'dbconnection.php';
    if (isset($_POST['complaintviewbydean'])) {
        $viewid = $_POST['viewcoid'];


        // $query = "SELECT * FROM `student` where email=";
        $query_run = mysqli_query($conn, "SELECT * FROM `grivence_register` where complaint_no='$viewid'");
        $count = mysqli_num_rows($query_run);
    }
    ?>

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>G_Details_Action</title>
        <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous"> -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700&display=swap');

            .container {
                max-width: 700px;
                width: 100%;
                background-color: #fff;
                padding: 20px 30px;
                border-radius: 5px;
                box-shadow: 0 10px 20px rgba(0, 0, 0, 0.15);
            }

            .img-fluid {
                height: 200px;
                width: 180px;
            }

            .profile-head {
                padding-top: 15px;
                padding-left: 20px;
            }

            .table {
                font-size: small;
            }

            .details,
            .table-dark {
                text-align: center;
            }

            .outer {
                padding-top: 30px;
                font-size: medium;
            }

            .btn {
                text-align: center;
            }
            .hide{
                display: none;
            }
        </style>

    </head>

    <body>
        <?php
        if ($count > 0) {
            $idno = 0;
            while ($row = mysqli_fetch_assoc($query_run)) {
                $idno = $idno + 1;
        ?>
                <div class="container-fluid">
                    <br>
                    <div class="card bg-light mb-3">
                        <div class="card-header">
                            <h3><b>> </b>Grievance Details </h3>
                        </div>
                        <div class="card-body">
                            <form>
                                <table class="table table-striped table-bordered">
                                    <tbody class="outer">
                                        <tr>
                                            <th scope="row">Grievance No.</th>
                                            <td><?php echo $idno; ?></td>
                                            <th scope="row">Complainant Id</th>
                                            <td>
                                                <?php
                                                require 'dbconnection.php';
                                                $squery = "SELECT * FROM `student` where id='" . $row['student_id'] . "'";
                                                $squery_run = mysqli_query($conn, $squery);
                                                foreach ($squery_run as $srn) {
                                                ?>


                                                    <a data-bs-toggle="modal" href="#staticBackdrop"><?php echo $srn['reg_no'] ?></a>
                                                <?php
                                                }
                                                ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="row">Registration Date</th>
                                            <td><?php echo $row['register_date'] ?></td>
                                            <th scope="row">Grievance Type</th>
                                            <td><?php echo $row['grivence_type'] ?></td>
                                        </tr>
                                        <tr>
                                            <th scope="row">Category</th>
                                            <td><?php echo $row['category'] ?></td>
                                            <th scope="row">Category Description (if any)</th>
                                            <td>No</td>
                                        </tr>
                                        <tr>
                                            <th scope="row">Nature of Grievance</th>
                                            <td colspan="5"><?php echo $row['noc'] ?></td>
                                        </tr>
                                        <tr>
                                            <th scope="row">Grievance Details</th>
                                            <td colspan="5"><?php echo $row['grivence_details'] ?></td>
                                        </tr>
                                        <tr>
                                            <th scope="row">remark</th>
                                            <td colspan="5"><?php echo $row['doucement'] ?></td>
                                        </tr>
                                        <tr>
                                            <th scope="row">last update time</th>
                                            <td colspan="5"><?php echo $row['doucement'] ?></td>
                                        </tr>
                                        <tr>
                                            <th scope="row">File (if any)</th>
                                            <td colspan="5"><?php echo $row['doucement'] ?></td>
                                        </tr>
                                        <tr>
                                            <th scope="row">Final status</th>
                                            <td colspan="5">
                                                <?php
                                                if ($row['status'] == "Closed") {
                                                    echo '<p class="btn btn-success">' . $row['status'] . '</p>';
                                                } else if ($row['status'] == "Inprogress") {
                                                    echo '<p class="btn btn-info">' . $row['status'] . '</p>';
                                                } else if ($row['status'] == "Rejected") {
                                                    echo '<p class="btn btn-danger">' . $row['status'] . '</p>';
                                                } else {
                                                    echo '<p class="btn btn-warning">Pending</p>';
                                                }

                                                ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th scope="row">

                                                Action
                                            </th>

                                            <td colspan="5">
                                                <?php
                                                require 'dbconnection.php';
                                                $view_query = "SELECT * FROM `grivence_register` where complaint_no='$viewid'";
                                                $view_query_run = mysqli_query($conn, $view_query);
                                                foreach ($view_query_run as $action) {
                                                ?>
                                                    <?php
                                                    if($action['status']=="Rejected" || $action['status']=="Closed" ){
                                                        echo '<button type="button" class="btn btn-outline-primary hide" data-bs-toggle="modal" data-bs-target="#action">Take Action</button>';
                                                    }else{
                                                        echo '<button type="button" class="btn btn-outline-primary " data-bs-toggle="modal" data-bs-target="#action">Take Action</button>';
                                                    }
                                                    ?>

                                                <?php
                                                }

                                                ?>
                                            </td>

                                        </tr>
                                    </tbody>
                                </table>
                            </form>
                        </div>
                    </div>
                    <!--Modal for Complainant profile-->
                    <div class="modal" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="staticBackdropLabel">> Complainant Details</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <?php
                                    require 'dbconnection.php';
                                    $squery = "SELECT * FROM `student` where id='" . $row['student_id'] . "'";
                                    $squery_run = mysqli_query($conn, $squery);
                                    foreach ($squery_run as $srnn) {
                                    ?>
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="profile-img">
                                                    <?php echo '<img src="studentimage/' . $srnn['image'] . '"
                                    alt="Generic placeholder image" class="img-fluid img-thumbnail mt-4 mb-2"
                                    style="width: 150px; z-index: 1">' ?>
                                                </div>
                                            </div>
                                            <div class="col-md-8 mt-5">
                                                <div class="profile-head">
                                                    <table class="table table-borderless">
                                                        <tr>
                                                            <th scope="col" id="col">Name</th>
                                                            <td><?php echo $srnn['name']; ?></td>
                                                        </tr>
                                                        <tr>
                                                            <th scope="col" id="col">Registration No.</th>
                                                            <td><?php echo $srnn['reg_no']; ?></td>
                                                        </tr>
                                                        <tr>
                                                            <th scope="col">Course</th>
                                                            <td><?php echo $srnn['stream']; ?></td>
                                                        </tr>
                                                    </table>
                                                </div>
                                            </div>
                                        </div><br>
                                        <div>
                                            <table class="table table-striped table-bordered">
                                                <thead class="table-dark">
                                                    <tr>
                                                        <th scope="col">Branch</th>
                                                        <th scope="col">Year</th>
                                                        <th scope="col">Semester</th>
                                                        <th scope="col">Contact</th>
                                                        <th scope="col">e-mail</th>
                                                    </tr>
                                                </thead>
                                                <tbody class="details">
                                                    <tr>
                                                        <td><?php echo $srnn['department']; ?></td>
                                                        <td>4th</td>
                                                        <td>7th</td>
                                                        <td><?php echo $srnn['contact_no']; ?></td>
                                                        <td><?php echo $srnn['email']; ?></td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    <?php
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--Modal for Action Panel-->
                    <div class="modal" id="action" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="actionLabel" aria-hidden="true">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="actionLabel">> Action Panel</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <form action="code.php" method="POST">
                                        <input type="hidden" value="<?php echo $row['complaint_no'] ?>" name="action_id">
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <label>Status</label>
                                            </div>
                                            <div class="col-sm-8">
                                                <select class="form-control" name="actionstatus">
                                                    <option selected>Select status...</option>
                                                    <option value="Inprogress">In Process</option>
                                                    <option value="Closed">Closed</option>
                                                    <option value="Rejected">Rejected</option>
                                                </select>
                                            </div>
                                        </div><br>
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <label>Remarks</label>
                                            </div>
                                            <div class="col-sm-8">
                                                <textarea class="form-control" id="g_det" rows="3" name="actionremark"></textarea>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="submit" name="grivence_action" class="btn btn-success">Submit</button>
                                        </div>
                                    </form>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
</div>
<?php
            }
        }
?>
</body>

</html>
</div>
<?php
include('includes/script.php');


?>