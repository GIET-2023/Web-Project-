<?php
session_start();
// if(!isset($_SESSION['username'])){
//     header('location:login.php');
//   }

include('includes/header.php');
// include('admin_sidenavbar.php   ');
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700&display=swap');

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 10px;
            background: linear-gradient(135deg, #71b7e6, #9b59b6);
        }

        .container {
            max-width: 700px;
            width: 100%;
            background-color: #fff;
            padding: 25px 30px;
            border-radius: 5px;
            box-shadow: 0 5px 10px rgba(0, 0, 0, 0.15);
        }

        .container .title {
            font-size: 25px;
            font-weight: 500;
            position: relative;
        }

        .container .title::before {
            content: "";
            position: absolute;
            left: 0;
            bottom: 0;
            height: 3px;
            width: 30px;
            border-radius: 5px;
            background: linear-gradient(135deg, #71b7e6, #9b59b6);
        }

        .content form .details {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            margin: 20px 0 12px 0;
        }

        form .details .input-box {
            margin-bottom: 15px;
            width: calc(100% / 2 - 20px);
        }

        form .input-box span.details {
            display: block;
            font-weight: 500;
            margin-bottom: 5px;
        }

        .input-box input {
            height: 45px;
            width: 100%;
            outline: none;
            font-size: 16px;
            border-radius: 5px;
            padding-left: 15px;
            border: 1px solid #ccc;
            border-bottom-width: 2px;
            transition: all 0.3s ease;
        }

        .form-control {
            height: 45px;
            width: 100%;
            outline: none;
            font-size: 16px;
            border-radius: 5px;
            padding-left: 15px;
            border: 1px solid #ccc;
            border-bottom-width: 2px;
            transition: all 0.3s ease;
        }

        .input-box input:focus,
        .input-box input:valid,
        .input-box option:focus,
        .input-box option:valid {
            border-color: #9b59b6;
        }

        .category {
            display: flex;
            width: 80%;
            margin: 14px 0;
            justify-content: space-between;
        }

        .category label {
            display: flex;
            align-items: center;
            cursor: pointer;
        }

        .category label .dot {
            height: 18px;
            width: 18px;
            border-radius: 50%;
            margin-right: 10px;
            margin-left: 10px;
            background: #d9d9d9;
            border: 5px solid transparent;
            transition: all 0.3s ease;
        }

        #dot-1:checked~.category label .one,
        #dot-2:checked~.category label .two,
        #dot-3:checked~.category label .three,
        #dot-4:checked~.category label .four,
        #dot-5:checked~.category label .five {
            background: #9b59b6;
            border-color: #d9d9d9;
        }

        form input[type="radio"] {
            display: none;
        }

        form .button {
            height: 45px;
            margin-left: 270px;
        }

        form .button input {
            height: 100%;
            width: 30%;
            border-radius: 5px;
            border: none;
            color: #fff;
            font-size: 18px;
            font-weight: 500;
            letter-spacing: 1px;
            cursor: pointer;
            transition: all 0.3s ease;
            background: linear-gradient(135deg, #71b7e6, #9b59b6);
        }

        form .button input:hover {
            /* transform: scale(0.99); */
            background: linear-gradient(-135deg, #71b7e6, #9b59b6);
        }

        @media(max-width: 584px) {
            .container {
                max-width: 100%;
            }

            form .details .input-box {
                margin-bottom: 15px;
                width: 100%;
            }

            form .category {
                width: 100%;
            }

            .content form .details {
                max-height: 300px;
                overflow-y: scroll;
            }

            .details::-webkit-scrollbar {
                width: 5px;
            }
        }

        @media(max-width: 459px) {
            .container .content .category {
                flex-direction: column;
            }
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="title">Student Admission</div>
        <a href="dashboard.php" class="float-right btn btn-success">Back to Home</a>
        <div class="content">
            <?php
            require 'dbconnection.php';
            if (isset($_POST['editstudent'])) {
                $editid = $_POST['editid'];
                $edit_query = "SELECT * FROM `student` WHERE id='$editid'";
                $edit_query_run = mysqli_query($conn, $edit_query);
                foreach ($edit_query_run as $row) {
            ?>

                    <form action="code.php" method="POST" enctype="multipart/form-data">
                        <input type="hidden" value="<?php echo $row['id'];?>" name="updateid">
                        <br>
                        <h3>Login Details</h3>
                        <div class="details">
                            <div class="input-box">
                                <span class="details">Username</span>
                                <input type="text" placeholder="Enter Username" value="<?php echo $row['name']; ?>">
                            </div>
                            <div class="input-box">
                                <span class="details">Password</span>
                                <input type="password" placeholder="Enter Password" name="upassword" value="<?php echo $row['password']; ?>" >
                            </div>
                        </div>
                        <br>
                        <h3>General Details</h3>
                        <div class="details">
                            <div class="input-box">
                                <span class="details">Name</span>
                                <input type="text" placeholder="Enter Name" name="uname" value="<?php echo $row['name']; ?>" >
                            </div>
                            <div class="input-box">
                                <span class="details">Course</span>
                                <select id="cat" class="form-control" name="ucourse" >
                                    <option selected><?php echo $row['stream']; ?></option>
                                    <option value="Btech">B.Tech</option>
                                    <option value="Btech_Le">B.Tech LE</option>
                                    <option value="Diploma">Diploma</option>
                                    <option value="MTech">M.Tech</option>
                                    <option value="Diploma_le">Diploma LE</option>
                                    <option value="MBA">MBA</option>
                                    <option value="MCA">MCA</option>
                                </select>
                            </div>
                            <div class="input-box">
                                <span class="details">Branch</span>
                                <select id="cat" class="form-control" name="ubranch" >
                                    <option selected><?php echo $row['department']; ?></option>
                                    <option value="MECH">Mechanical Engg.</option>
                                    <option value="CIVIL">Civil Engg.</option>
                                    <option value="EE">Electrical Engg.</option>
                                    <option value="EEE">Electrical & Electronics Engg.</option>
                                    <option value="CSE">Computer Science Engg.</option>
                                    <option value="EACE">Electrical And Computer Engg.</option>
                                    <option value="ECE">Electronis & Communication Engg.</option>
                                    <option value="MBA">MBA</option>
                                    <option value="MCA">MCA</option>
                                </select>
                            </div>
                            <div class="input-box">
                                <label>
                                    <span class="details">Date of Birth:</span>
                                    <input type="date" name="udob" value="<?php echo $row['dob']; ?>"  pattern="\d{4}-\d{2}-\d{2}" />
                                    <span class="validity"></span>
                                </label>
                            </div>
                            <div class="input-box">

                                <span class="details">Gender</span>
                                <div class="category">
                                    <select id="" class="form-control" name="ugender" >
                                        <option selected><?php echo $row['gender']; ?></option>
                                        <option value="male">Male</option>
                                        <option value="female">Female</option>
                                        <option value="other">Other</option>
                                    </select>
                                </div>
                            </div>
                            <div class="input-box">
                                <span class="details">Domicile</span>

                                <div class="category">
                                    <select id="" class="form-control" >
                                        <option value="">Choose here</option>
                                        <option value="odisha">ODISHA</option>
                                        <option value="outside">OUTSIDE</option>
                                    </select>
                                </div>
                            </div>
                            <div class="input-box">
                                <span class="details">Nationality</span>
                                <input type="text" placeholder="Enter Nationality" name="unationality" value="<?php echo $row['nationality']; ?>" >
                            </div>
                            <div class="input-box">
                                <span class="details">Cast</span>
                                <select id="cat" class="form-control" name="ucast" >
                                    <option selected> <?php echo $row['cast']; ?></option>
                                    <option value="general">General</option>
                                    <option value="sc">SC</option>
                                    <option value="st">ST</option>
                                    <option value="obc">OBC</option>
                                    <option value="greencard">Green Card</option>
                                    <option value="defence">Defence</option>
                                    <option value="women">Women</option>
                                    <option value="ews">EWS</option>
                                </select>
                            </div>
                            <div class="input-box">
                                <span class="details">Mother Tongue</span>
                                <input type="text" value="<?php echo $row['mothertounge']; ?>" placeholder="Enter Mother Tongue" name="umothertongue" >
                            </div>
                            <div class="input-box">
                                <span class="details">Religion</span>
                                <input type="text" value="<?php echo $row['religion']; ?>" placeholder="Enter Religion" name="ureligion" >
                            </div>
                            <div class="input-box">
                                <span class="details">Aadhaar Card Number</span>
                                <input type="text" value="<?php echo $row['adhar_no']; ?>" placeholder="Enter Aadhaar Card Number" name="uadhar" >
                            </div>
                            <div class="input-box">
                                <span class="details">Blood Group</span>
                                <input type="text" value="<?php echo $row['blod_group']; ?>" placeholder="Enter Blood Group" name="ublodgroup" >
                            </div>
                            <div class="input-box">
                                <span class="details">Birth Place</span>
                                <input type="text" value="<?php echo $row['birth_place']; ?>" placeholder="Enter Birth Place" name="ubirthplace" >
                            </div>
                            <div class="input-box">
                                <span class="details">Cuntry</span>
                                <input type="text" value="<?php echo $row['country']; ?>" placeholder="Enter Cuntry name " name="ucuntry">
                            </div>
                        </div>
                        <br>
                        <h3>Parent's Details</h3>
                        <div class="details">
                            <div class="input-box">
                                <span class="details">Father's Name</span>
                                <input type="text" value="<?php echo $row['father_name']; ?>" placeholder="Enter Father's Name" name="ufname" >
                            </div>
                            <div class="input-box">
                                <span class="details">Mothers's Name</span>
                                <input type="text" value="<?php echo $row['mother_name']; ?>" placeholder="Enter Father's Name" name="umname" >
                            </div>
                            <div class="input-box">
                                <span class="details">Father's Qualification</span>
                                <input type="text" value="<?php echo $row['father_qualification']; ?>" placeholder="Enter Father's Name" name="ufq" >
                            </div>
                            <div class="input-box">
                                <span class="details">Mothers's Qualification</span>
                                <input type="text" value="<?php echo $row['mother_qualification']; ?>" placeholder="Enter Father's Name" name="umq" >
                            </div>
                            <div class="input-box">
                                <span class="details">Father's Occupation</span>
                                <input type="text" value="<?php echo $row['father_occupation']; ?>" placeholder="Enter Father's Name" name="ufo" >
                            </div>
                            <div class="input-box">
                                <span class="details">Mothers's Occupation</span>
                                <input type="text" value="<?php echo $row['mother_occupation']; ?>" placeholder="Enter Father's Name" name="umo" >
                            </div>
                        </div>
                        <br>
                        <h3>Postal Details</h3>
                        <div class="details">
                            <div class="input-box">
                                <span class="details">Address</span>
                                <input type="text" value="<?php echo $row['adress']; ?>" placeholder="Enter Address" name="uadress" >
                            </div>
                            <div class="input-box">
                                <span class="details">City</span>
                                <input type="text" value="<?php echo $row['city']; ?>" placeholder="Enter City" name="ucity" >
                            </div>
                            <div class="input-box">
                                <span class="details">State</span>
                                <input type="text" value="<?php echo $row['state']; ?>" placeholder="Enter State" name="ustate" >
                            </div>
                            <div class="input-box">
                                <span class="details">PIN Code</span>
                                <input type="text" value="<?php echo $row['pincode']; ?>" placeholder="Enter Pin" name="upincode" maxlength="7" >
                            </div>
                        </div>
                        <br>
                        <h3>Contact Details</h3>
                        <div class="details">
                            <div class="input-box">
                                <span class="details">Phone</span>
                                <input type="text" value="<?php echo $row['contact_no']; ?>" placeholder="Enter Phone" name="umobile" maxlength="10" >
                            </div>
                            <div class="input-box">
                                <span class="details">e-mail ID</span>
                                <input type="email" value="<?php echo $row['email']; ?>" placeholder="Enter E-mail ID" name="uemail" >
                            </div>
                            <div class="input-box">
                                <span class="details">Father's Contact</span>
                                <input type="text" value="<?php echo $row['father_contact_no']; ?>" placeholder="Enter your Father's contact" name="ufmobile" maxlength="10">
                            </div>
                            <div class="input-box">
                                <span class="details">Mother's Contact</span>
                                <input type="text" value="<?php echo $row['mother_contact_no']; ?>" placeholder="Enter your Mother's Contact" name="ummobile" maxlength="10">
                            </div>
                        </div>
                        <br>
                        <h3>Admission Details</h3>
                        <div class="details">
                            <div class="input-box">
                                <span class="details">Admission Number</span>
                                <input type="text" value="<?php echo $row['reg_no']; ?>" placeholder="Enter Regd. No." name="uregno" >
                            </div>
                            <div class="input-box">
                                <label>
                                    <span class="details">Date of Admission:</span>
                                    <input type="date" value="<?php echo $row['admission_date']; ?>"   name="udoa"  pattern="\d{4}-\d{2}-\d{2}" />
                                    <span class="validity"></span>
                                </label>
                            </div>
                        </div>
                        <div class="details">
                            <div class="input-box">
                                <span class="details">Status</span>
                                <select id="cat" class="form-control" name="ustatus">
                                    <option selected><?php echo $row['status']; ?></option>
                                    <option value="active">Active</option>
                                    <option value="inactive">Inactive</option>
                                </select>
                            </div>
                            <div class="input-box">
                                <span class="details">Usertype</span>
                                <select id="cat" class="form-control" name="uusertype">
                                    <option selected><?php echo $row['usertype']; ?></option>
                                    <option value="student">Student</option>
                                    <option value="faculty">Faculty</option>
                                    <option value="admin">Admin</option>
                                    <option value="principal">Principal</option>
                                    <option value="superadmin">Super Admin</option>
                                    <option value="dean">Dean</option>
                                </select>
                            </div>
                            <div class="input-box">
                                <span class="details">Student Image</span>
                                <input type="file" value="<?php echo $row['image']; ?>" name="uimage" >
                            </div>
                            <div class="input-box">
                            <div class="profile-img">
                               <?php echo '<img src="studentimage/' . $row['image'] . '" class="img-fluid img-thumbnail mt-4 mb-2">'?>
                            </div>
                            </div>
                        </div>
                        <div class="button">

                            <button type="submit" class="btn btn-success" name="student_update">UPDATE</button>
                        </div>
                    </form>
            <?php
                }
            }
            ?>
        </div>
    </div>
</body>

</html>


<?php
include('includes/script.php');
?>