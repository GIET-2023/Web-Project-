<?php
session_start();
// if(!isset($_SESSION['username'])){
//     header('location:login.php');
//   }

include('includes/header.php');
include('includes/admin_sidenavbar.php');


?>

    <!-- <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Student Registrartion</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="code.php" method="post" enctype="multipart/form-data">
                        <div class="form-group">'
                            <label for="" style="color: red; font-weight:bolder;font-size:larger;">Select your Department</label>
                            <select name="department" id="" class="form-control">
                                <option value="">Choose your Department</option>
                                <option value="CSE">CSE</option>
                                <option value="EACE">EACE</option>
                                <option value="EE">EE</option>
                                <option value="ECE">ECE</option>
                                <option value="MECH">MECH</option>
                            </select>
                        </div>
                        <div class="form-group">'
                            <label for="" style="color: red; font-weight:bolder;font-size:larger;">Stream</label>
                            <select name="stream" id="" class="form-control">
                                <option value="">Choose your Stream</option>
                                <option value="BTECH">BTECH</option>
                                <option value="MTECH">MTECH</option>
                                <option value="DIPLOMA">DIPLOMA</option>
                                <option value="MCA">MCA</option>
                                <option value="MBA">MBA</option>
                            </select>
                        </div>
                        <div class="form-group">'
                            <label for="" style="color: red; font-weight:bolder;font-size:larger;">Usertype</label>
                            <select name="usertype" id="" class="form-control">
                                <option value="">Choose usertype</option>
                                <option value="User">User</option>
                                <option value="Admin">Admin</option>

                            </select>
                        </div>

                        <div class="form-group">'
                            <label for="" style="color: red; font-weight:bolder;font-size:larger;">Uplod image</label>
                            <input type="file" name="image" class="form-control" require>
                        </div>
                        <div class="form-group">'
                            <label for="" style="color: red; font-weight:bolder;font-size:larger;">Name</label>
                            <input type="text" name="name" class="form-control" placeholder="Enter username" require>
                        </div>
                        <div class="form-group">'
                            <label for="" style="color: red; font-weight:bolder;font-size:larger;">Registration_no</label>
                            <input type="text" name="reg_no" class="form-control" placeholder="Enter Registrartion No" require>
                        </div>
                        <div class="form-group">'
                            <label for="" style="color: red; font-weight:bolder;font-size:larger;">Mobile_No</label>
                            <input type="text" name="mobile" class="form-control" placeholder="Enter mobile no" require>
                        </div>
                        <div class="form-group">'
                            <label for="" style="color: red; font-weight:bolder;font-size:larger;">Email</label>
                            <input type="email" name="email" class="form-control" placeholder="Enter your email" require>
                        </div>
                        <div class="form-group">'
                            <label for="" style="color: red; font-weight:bolder;font-size:larger;">Parents</label>
                            <input type="text" name="spname" class="form-control" placeholder="Enter Parents name" require>
                        </div>
                        <div class="form-group">'
                            <label for="" style="color: red; font-weight:bolder;font-size:larger;">Parents contact No</label>
                            <input type="text" name="spmobile" class="form-control" placeholder="Enter contact no" require>
                        </div>

                        <div class="form-group">'
                            <label for="" style="color: red; font-weight:bolder;font-size:larger;">Password</label>
                            <input type="password" name="password" class="form-control" placeholder="Enter Student password" require>
                        </div>
                        <div class="form-group">'
                            
                            <input type="hidden" name="status" value="inactive" class="form-control" require>
                        </div>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary" name="addstudent">Save </button>
                    </form>
                </div>

            </div>
        </div>
    </div>
    <div class="modal fade" id="facultyModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Faculty Registrartion</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="code.php" method="post" enctype="multipart/form-data">
                        <div class="form-group">'
                            <label for="" style="color: red; font-weight:bolder;font-size:larger;">Select your Department</label>
                            <select name="department" id="" class="form-control">
                                <option value="">Choose your Department</option>
                                <option value="CSE">CSE</option>
                                <option value="EACE">EACE</option>
                                <option value="EE">EE</option>
                                <option value="ECE">ECE</option>
                                <option value="MECH">MECH</option>
                            </select>
                        </div>

                        <div class="form-group">'
                            <label for="" style="color: red; font-weight:bolder;font-size:larger;">Usertype</label>
                            <select name="usertype" id="" class="form-control">
                                <option value="">Choose usertype</option>
                                <option value="User">User</option>
                                <option value="Admin">Admin</option>

                            </select>
                        </div>

                        <div class="form-group">'
                            <label for="" style="color: red; font-weight:bolder;font-size:larger;">Uplod image</label>
                            <input type="file" name="image" class="form-control">
                        </div>
                        <div class="form-group">'
                            <label for="" style="color: red; font-weight:bolder;font-size:larger;">Name</label>
                            <input type="text" name="name" class="form-control" placeholder="Enter username" require>
                        </div>
                        <div class="form-group">'
                            <label for="" style="color: red; font-weight:bolder;font-size:larger;">Faculty_id</label>
                            <input type="text" name="f_id" class="form-control" placeholder="Enter Registrartion No" require>
                        </div>
                        <div class="form-group">'
                            <label for="" style="color: red; font-weight:bolder;font-size:larger;">Mobile_No</label>
                            <input type="text" name="mobile" class="form-control" placeholder="Enter mobile no" require>
                        </div>
                        <div class="form-group">'
                            <label for="" style="color: red; font-weight:bolder;font-size:larger;">Email</label>
                            <input type="email" name="email" class="form-control" placeholder="Enter your email" require>
                        </div>
                        <div class="form-group">'
                            <label for="" style="color: red; font-weight:bolder;font-size:larger;">Adress</label>
                            <input type="text" name="adress" class="form-control" placeholder="Enter Parents name" require>
                        </div>

                        <div class="form-group">'
                            <label for="" style="color: red; font-weight:bolder;font-size:larger;">Password</label>
                            <input type="password" name="password" class="form-control" placeholder="Enter Student password" require>
                        </div>
                        <div class="form-group">'
                            
                            <input type="hidden" name="status" value="inactive" class="form-control" require>
                        </div>
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary" name="addfaculty">Save </button>
                    </form>
                </div>

            </div>
        </div>
    </div> -->

    <div class="container">
        <div class="content" style="margin-left:35vh ;">
            <span style="font-weight:bolder; font-size:xxx-large;color:#000000;"> Registrartion Page</span>
        </div>
    </div>

    <div class="conatiner-fluid">
        <div class="content-wrapper">
            <div class="container-fluid">
                <div class="card shadow mb-5">
                    <div class="card-header py-3" style="background-color: #4863A0;">

                        <h2 class="m-4 font-weight-bold text-primary"><span style="color: #0AFFFF;"> Sudent Register</span>
                            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal" style="background-color:red ;">
                                Add Student
                            </button>


                        </h2>

                    </div>

                </div>
            </div>
            <div class="container-fluid">
                <div class="card shadow mb-5">
                    <div class="card-header py-3"style="background-color: #4863A0;">

                        <h2 class="m-4 font-weight-bold text-primary"><span style="color: #0AFFFF;">Faculty Register</span>
                            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#facultyModal" style="background-color:red ;">
                                Add Faculty
                            </button>

                        </h2>

                    </div>

                </div>
            </div>
        </div>
    </div>
    <!-- faculty modal  -->
   


   

<?php
include('includes/script.php');


?>