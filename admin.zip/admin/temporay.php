<div class="container">
    <div class="content" style="margin-left:40% ;">
        <span style="font-weight:bolder; font-size:xxx-large;color:#000000;">Grivence History</span>
    </div>
</div>
<div class="content-wrapper">
    <div class="container-fluid">
        <div class="card shadow mb-5">
            <div class="card-header py-3" style="background-color: #123456;">
                <h6 class="m-4 font-weight-bold text-primary"><span style="font-weight:bolder; font-size:x-large;color:#7FFFD4;">All Complaints</span> </h6>
            </div>
            <div class="card-body">
                <table _ngcontent-sow-c12="" class="table table-bordered" width="100%" cellspacing="0" id="myTable">
                    <?php
                    require 'dbconnection.php';
                    $query = "SELECT * FROM `grivence_register`";
                    $query_run = mysqli_query($conn, $query);
                    $num_query = mysqli_num_rows($query_run);

                    ?>
                    <thead _ngcontent-sow-c12="" class="thead-light">
                        <tr _ngcontent-sow-c12="">
                            <td _ngcontent-sow-c12="">COMPLAINT_NO</td>
                            <td _ngcontent-sow-c12="">STUDENT_ID</td>
                            <td _ngcontent-sow-c12="">CATEGORY</td>
                            <td _ngcontent-sow-c12="">COMPLAINT_TYPE</td>
                            <td _ngcontent-sow-c12="">NOC</td>
                            

                            <td _ngcontent-sow-c12="">Status</td>

                        </tr>
                    </thead>
                    <tbody _ngcontent-sow-c12="">
                        <?php
                        if ($num_query > 0) {
                            while ($row = mysqli_fetch_assoc($query_run)) {
                        ?>
                                <tr _ngcontent-sow-c12="">
                                    <td _ngcontent-sow-c12=""><?php echo $row['complaint_no']; ?></td>
                                    <td _ngcontent-sow-c12=""><?php echo $row['student_id']; ?></td>
                                    <td _ngcontent-sow-c12=""><?php echo $row['category']; ?></td>
                                    <td _ngcontent-sow-c12=""><?php echo $row['grivence_type']; ?></td>
                                    <td _ngcontent-sow-c12=""><?php echo $row['noc']; ?></td>
                                    
                                    <td _ngcontent-sow-c12=""><?php 
                                     if($row['status']=="closed"){
                                        echo '<p class="btn btn-success">'.$row['status'].'</p>';
                                     }
                                     else if($row['status']=="inprogress"){
                                        echo '<p class="btn btn-info">'.$row['status'].'</p>';
                                     }else{
                                        echo '<p class="btn btn-danger">Pending</p>';
                                     }
                                    
                                    ?></td>
                                </tr>
                        <?php
                            }
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>