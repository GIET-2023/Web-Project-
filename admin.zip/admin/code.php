<?php
session_start();
require 'dbconnection.php';
// student registeration
if (isset($_POST['student_admission'])) {
    $password = $_POST['password'];
    $name = $_POST['name'];
    $course = $_POST['course'];
    $branch = $_POST['branch'];
    $dob = $_POST['dob'];
    $gender = $_POST['gender'];
    $nationality = $_POST['nationality'];
    $cast = $_POST['cast'];
    $mothertongue = $_POST['mothertongue'];
    $religion = $_POST['religion'];
    $adhar = $_POST['adhar'];
    $blodgroup = $_POST['blodgroup'];
    $birthplace = $_POST['birthplace'];
    $fname = $_POST['fname'];
    $mname = $_POST['mname'];
    $fq = $_POST['fq'];
    $mq = $_POST['mq'];
    $fo = $_POST['fo'];
    $mo = $_POST['mo'];
    $adress = $_POST['adress'];
    $city = $_POST['city'];
    $state = $_POST['state'];
    $pincode = $_POST['pincode'];
    $mobile = $_POST['mobile'];
    $email = $_POST['email'];
    $fmobile = $_POST['fmobile'];
    $mmobile = $_POST['mmobile'];
    $regno = $_POST['regno'];
    $doa = $_POST['doa'];
    $status = $_POST['status'];
    $usertype = $_POST['usertype'];
    $image = $_FILES["image"]['name'];
    $cuntry = $_POST['cuntry'];

    $check_query = "SELECT * FROM `student` WHERE reg_no='$regno'";
    $check_query_run = mysqli_query($conn, $check_query);
    $check_query_count = mysqli_num_rows($check_query_run);
    if ($check_query_count > 0) {
        $_SESSION['status'] = "Sorry ! Registartion number already exist.";
        $_SESSION['status_code'] = "warning";
        header('location:student_register.php');
    } else {
        if (file_exists("studentimage/" . $_FILES["image"]["name"])) {
            $store = $_FILES['image']['name'];
            $_SESSION['status'] = "Iamge already exists";
            $_SESSION['status_code'] = "error";
            header('location:student_register.php');
        } else {
            $s_register_query = "INSERT INTO `student`(`image`, `name`, `reg_no`, `stream`, `department`, `admission_date`, `dob`, `gender`, `nationality`, `mothertounge`, `cast`, `religion`, `adhar_no`, `email`, `adress`, `city`, `state`, `pincode`, `country`, `birth_place`, `father_name`, `mother_name`, `contact_no`, `father_contact_no`, `mother_contact_no`, `father_qualification`, `mother_qualification`, `father_occupation`, `mother_occupation`, `blod_group`, `password`, `status`, `usertype`) VALUES ('$image','$name','$regno','$course','$branch','$doa','$dob','$gender','$nationality','$mothertongue','$cast','$religion','$adhar','$email','$adress','$city','$state','$pincode','$cuntry','$birthplace','$fname','$mname','$mobile','$fmobile','$mmobile','$fq','$mq','$fo','$mo','$blodgroup','$password','$status','$usertype')";

            $s_register_query_run = mysqli_query($conn, $s_register_query);
            if ($s_register_query_run) {
                move_uploaded_file($_FILES["image"]["tmp_name"], "studentimage/" . $_FILES["image"]["name"]);
                $_SESSION['username'] = $name;
                $_SESSION['status'] = "Student Register successfully";
                $_SESSION['status_code'] = "success";
                header('location:student_register.php');
            } else {
                $_SESSION['studentstatus'] = "Student register  Failed";
                $_SESSION['status_code'] = "error";
                header('location:student_register.php');
            }
        }
    }
}

// end student registartion

// update student details
if(isset($_POST['student_update'])){
    $updateid = $_POST['updateid'];
    $password = $_POST['upassword'];
    $name = $_POST['uname'];
    $course = $_POST['ucourse'];
    $branch = $_POST['ubranch'];
    $dob = $_POST['udob'];
    $gender = $_POST['ugender'];
    $nationality = $_POST['unationality'];
    $cast = $_POST['ucast'];
    $mothertongue = $_POST['umothertongue'];
    $religion = $_POST['ureligion'];
    $adhar = $_POST['uadhar'];
    $blodgroup = $_POST['ublodgroup'];
    $birthplace = $_POST['ubirthplace'];
    $fname = $_POST['ufname'];
    $mname = $_POST['umname'];
    $fq = $_POST['ufq'];
    $mq = $_POST['umq'];
    $fo = $_POST['ufo'];
    $mo = $_POST['umo'];
    $adress = $_POST['uadress'];
    $city = $_POST['ucity'];
    $state = $_POST['ustate'];
    $pincode = $_POST['upincode'];
    $mobile = $_POST['umobile'];
    $email = $_POST['uemail'];
    $fmobile = $_POST['ufmobile'];
    $mmobile = $_POST['ummobile'];
    $regno = $_POST['uregno'];
    $doa = $_POST['udoa'];
    $status = $_POST['ustatus'];
    $usertype = $_POST['uusertype'];
    $image = $_FILES["uimage"]['name'];
    $cuntry = $_POST['ucuntry'];
    
    $search_query = "SELECT * FROM `student` where id='$updateid'";
    $search_query_run = mysqli_query($conn, $search_query);
    foreach ($squery_run as $row) {
        // echo $row['images'];
        if ($image == NULL) {
            $imagedata = $row['image'];
        } else {
            if ($imagepath = "studentimage/" . $row['image']) {
                unlink($imagepath);
                $imagedata = $image;
            }
        }
    }
    $update_query ="UPDATE `student` SET `id`='$updateid',`image`='$image',`name`='$name',`reg_no`='$regno',`stream`='$course',`department`='$branch',`admission_date`='$doa',`dob`='$dob',`gender`='$gender',`nationality`='$nationality',`mothertounge`='$mothertongue',`cast`='$cast',`religion`='$religion',`adhar_no`='$adhar',`email`='$email',`adress`='$adress',`city`='$city',`state`='$state',`pincode`='$pincode',`country`='$cuntry',`birth_place`='$birthplace',`father_name`='$fname',`mother_name`='$mname',`contact_no`='$mobile',`father_contact_no`='$fmobile',`mother_contact_no`='$mmobile',`father_qualification`='$fq',`mother_qualification`='$mq',`father_occupation`='$fo',`mother_occupation`='$mo',`blod_group`='$blodgroup',`password`='$password',`status`='$status',`usertype`='$usertype' WHERE id='$updateid'";
    $update_query_run = mysqli_query($conn,$update_query);
    if($update_query_run){
        if ($image == NULL) {
            $_SESSION['status'] = "updated  successfully ";
            $_SESSION['status_code'] = "success";
            header('location:student_update.php');
        } else {
            move_uploaded_file($_FILES["uimage"]["tmp_name"], "studentimage/" . $_FILES["uimage"]["name"]);
            $_SESSION['status'] = "Student updated successfully";
            $_SESSION['status_code'] = "success";
            header('location:student_update.php');
        }

    }
    else
    {
        $_SESSION['status'] = "Failed to update student ";
        $_SESSION['status_code'] = "error";
        header('location:student_update.php');
    }
}

// end update student details

// student delete code
if(isset($_POST['deletestudent'])){
    $deleteid = $_POST['deleteid'];
    $deletequery = "DELETE FROM `student` WHERE id='$deleteid'";
    $deletequery_run = mysqli_query($conn, $deletequery);
    if ($deletequery_run) {
        $_SESSION['status'] = "Student deleted successfully";
        $_SESSION['status_code'] = "success";
        header('location:student.php');
    } else {
        echo "error";
    }
}

// end student delete code
// login code logic
if(isset($_POST['login'])){
    $loginusername = $_POST['loginusername'];
    $loginpassword = $_POST['loginpassword'];
    $login_query = "SELECT * FROM `student` where reg_no='$loginusername' AND  password='$loginpassword'";
    $login_query_run = mysqli_query($conn, $login_query);
    $login_status = mysqli_fetch_array($login_query_run);

    if($login_status['status'] == "active"){
        $login_queryu = "SELECT * FROM `student` where reg_no='$loginusername' AND  password='$loginpassword'";
        $login_query_runu = mysqli_query($conn, $login_queryu);
        $login_usertype = mysqli_fetch_array($login_query_runu);
        if($login_usertype['usertype'] == "student"){
            $_SESSION['studentusername'] = $loginusername;
            $_SESSION['status'] = "Login Successfully";
            $_SESSION['status_code'] = "success";
            header('location:student/index.php');
        }
        else if($login_usertype['usertype'] == "admin"){
            $_SESSION['studentusername'] = $loginusername;
            $_SESSION['status'] = "Login Successfully";
            $_SESSION['status_code'] = "success";
            header('location:dashboard.php');
        }
        else if($login_usertype['usertype'] == "dean"){
            $_SESSION['studentusername'] = $loginusername;
            $_SESSION['status'] = "Login Successfully";
            $_SESSION['status_code'] = "success";
            header('location:dean_dashboard.php');
        }
        else{
            header('location:login.php');
            $_SESSION['statusstudent'] = "User not allowed in system";
        }
    }else
    {

    }
}

// end login code

// grivence compalinet register logic
if(isset($_POST['complaint_register'])){
    $g_userid = $_POST['g_userid'];
    $category_id = $_POST['category_id'];
    $grivence_type = $_POST['grivence_type'];
    $desc = $_POST['desc'];
    $managementtype = $_POST['managementtype'];
    $gstatus = $_POST['gstatus'];
    $noc = $_POST['noc'];
    $document = $_FILES["document"]['name'];
    $grivence_details = $_POST['grivence_details'];
  
    $complaint_query = "INSERT INTO `grivence_register`(`student_id`, `category`, `grivence_type`, `dean_type`, `noc`, `grivence_details`, `doucement`,`status`) VALUES ('$g_userid','$category_id','$grivence_type','$managementtype','$noc','$grivence_details','$document','$gstatus')";

    $complaint_query_run = mysqli_query($conn,$complaint_query);
    if($complaint_query_run){
        move_uploaded_file($_FILES["document"]["tmp_name"], "g_document/" . $_FILES["document"]["name"]);
        $_SESSION['studentid'] = $g_userid;
        $_SESSION['status'] = "Complaint Register successfully";
        $_SESSION['status_code'] = "success";
        header('location:student/grivence_complaint.php');
    }
    else
    {
        $_SESSION['status'] = "Complaint register  Failed";
        $_SESSION['status_code'] = "error";
        header('location:student/grivence_complaint.php');
    }

}


// end complaint register


// Grivence  study action logics code

if(isset($_POST['grivence_action'])){
    $remarkid = $_POST['action_id'];
    $actionstatus = $_POST['actionstatus'];
    $actionremark = $_POST['actionremark'];
    $action_query = "UPDATE `grivence_register` SET `complaint_no`='$remarkid',`status`='$actionstatus',`remark`='$actionremark' WHERE complaint_no='$remarkid'";
    $action_query_run = mysqli_query($conn,$action_query);
    if($action_query){
        $_SESSION['status'] = "Complaint updated";
        $_SESSION['status_code'] = "success";
        header('location:grivence_dean_complainthistory.php');
    }else{
        $_SESSION['status'] = "Complaint error  Failed";
        $_SESSION['status_code'] = "error";
        header('location:grivence_dean_complainthistory.php');
    }
     
}
// if(isset($_POST['grivence_action'])){
//     $remarkid = $_POST['action_id'];
//     // $actionremarkstatus = $_POST['actionstatus'];
//     $remark = $_POST['actionremark'];
//     $action_remark_query = "INSERT INTO `grievance_remark`(`complaint_no`, `remark``) VALUES ('$remarkid','$remark')";
//     $action_remark_query_run = mysqli_query($conn,$action_remark_query);
//     if($action_remark_query_run){
//         $_SESSION['status'] = "Complaint updated";
//         $_SESSION['status_code'] = "success";
//         header('location:grivence_dean_complainthistory.php');
//     }else{
//         $_SESSION['status'] = "Complaint error  Failed";
//         $_SESSION['status_code'] = "error";
//         header('location:grivence_dean_complainthistory.php');
//     }
     
// }

// end grivence action logic codes