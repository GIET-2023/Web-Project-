<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "eims2";
$conn = mysqli_connect($servername,$username,$password,$dbname);
 
?>