<?php
session_start();
include('includes/header.php');
include('student_navabr.php');
// include('includes/footer.php');

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>G_Tables</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet">

</head>

<body>
    <div class="container-fluid">
        <br>
        <div class="card bg-light mb-3">
            <div class="card-header">
                <h3><b>> </b>Grievance Register </h3>
            </div>
            <div class="card-body">
                <form action="../code.php" method="POST" enctype="multipart/form-data">
                    <?php
                    require 'dbconnection.php';
                    $gquery_run = mysqli_query($conn, "SELECT * FROM `student` where reg_no='" . $_SESSION['studentusername'] . "'");
                    foreach ($gquery_run as $urow) {
                    ?>

                        <input type="hidden" name="g_userid" value="<?php echo $urow['id']; ?>">
                    <?php
                    }
                    ?>
                        <input type="hidden" name="gstatus" value="Pending">
                    <div class="form-row">

                        <div class="form-group col-md-6">

                            <div class="form-group row">
                                <label for="inputcat" class="col-sm-4 col-form-label">Category</label>
                                <div class="col-sm-7">
                                    <select id="cat" class="form-control" name="category_id">
                                        <option selected>Select category...</option>
                                        <option value="hostel">Hostel</option>
                                        <option value="college">college</option>

                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="form-group col-md-6">
                            <div class="form-group row">
                                <label for="inputg_type" class="col-sm-3 col-form-label">Grievance Type</label>
                                <div class="col-sm-9">
                                    <select id="g_type" class="form-control" name="grivence_type">
                                        <option selected>Select type...</option>
                                        <option>Complaint</option>
                                        <option>General Query</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <div class="form-group row">
                                <label for="inputcat_des" class="col-sm-4 col-form-label">Category Description (if
                                    any)</label>
                                <div class="col-sm-7">
                                    <textarea class="form-control" id="cat-des" rows="3" name="desc"></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="form-group col-md-6">
                            <div class="form-group row">
                                <label for="inputd_type" class="col-sm-3 col-form-label">Management</label>
                                <div class="col-sm-9    ">
                                    <div class="row">
                                        <select id="g_type" class="form-control" name="managementtype">
                                            <option value="" selected>select management type</option>
                                            <option value="principal">Principal</option>
                                            <option value="student_affires">Student_Affires</option>
                                            <option value="academics">academics</option>
                                            <option value="r&d">R & D</option>
                                            <option value="transport">Transport</option>
                                            <option value="accounts">Accounts</option>
                                            <option value="t&p">T & P</option>
                                            <option value="administative">Administative</option>
                                            <option value="admin">Admin</option>
                                        </select>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-row">

                        <div class="form-group col-md-6">
                            <div class="form-group row">
                                <label for="inputnoc" class="col-sm-4 col-form-label">Nature of Grievance</label>
                                <div class="col-sm-7">
                                    <input type="text" class="form-control" id="inputnoc" name="noc">
                                </div>
                            </div>
                        </div>
                        <div class="form-group col-md-6">
                            <div class="form-group row">
                                <label for="inputg_type" class="col-sm-4 col-form-label">Related Doc (if any)</label>
                                <div class="col-sm-8">
                                    <div class="card" style="padding-top:4px;padding-bottom:4px;padding-left:5px;">
                                        <input type="file" class="form-control-file" id="r_doc" name="document">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-8">
                            <div class="form-group row">
                                <label for="inputg_det" class="col-sm-3 col-form-label">Grievance Details</label>
                                <div class="col-sm-7">
                                    <textarea class="form-control" id="g_det" rows="3" name="grivence_details"></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div style="text-align: center;">
                        <button type="submit" class="btn btn-primary" name="complaint_register">Submit</button>
                    </div>
                </form>
            </div>
        </div>

    </div>
</body>

</html>
<?php

include('includes/script.php');
?>