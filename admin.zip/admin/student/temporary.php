<!DOCTYPE html>
<html lang="en">
<?php
require 'dbconnection.php';
// $query = "SELECT * FROM `student` where email=";
$query_run = mysqli_query($conn, "SELECT * FROM `student` where reg_no='" . $_SESSION['studentusername'] . "'");
$count = mysqli_num_rows($query_run);
?>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MyProfile</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <style>
        .accordion-button {
            background-color: #e7e7e7;
        }
    </style>
</head>

<body>

    <section class=" gradient-custom-2">
        <?php
        if ($count > 0) {
            $idno = 0;
            while ($row = mysqli_fetch_assoc($query_run)) {
                $idno = $idno + 1;
        ?>
                <div class="container">
                    <div class="row d-flex justify-content-center align-items-center ">
                        <div class="col col-lg-6 col-xl-10">
                            <div class="card">
                                <div class="rounded-top text-white d-flex flex-row" style="background-color: rgb(0, 0, 35); height:200px;">
                                    <div class="ms-4 mt-5 d-flex flex-column" style="width: 150px;">
                                        <?php echo '<img src="../studentimage/' . $row['image'] . '"
                                    alt="Generic placeholder image" class="img-fluid img-thumbnail mt-4 mb-2"
                                    style="width: 150px; z-index: 1">' ?>
                                        <button type="button" class="btn btn-outline-dark" data-mdb-ripple-color="dark" style="z-index: 1;">
                                            Edit profile
                                        </button>
                                    </div>
                                    <div class="ms-5" style="margin-top: 130px;">
                                        <h5><?php echo $row['name']; ?></h5>
                                        <p><i>B.Tech Computer Sc & Engg.</i></p>
                                    </div>
                                </div>
                                <div class="p-4 text-black" style="background-color: #f8f9fa;">
                                    <div class="d-flex justify-content-end text-center py-1">
                                        <div>
                                            <p class="mb-1 h6">2019-23</p>
                                            <p class="small text-muted mb-0">Batch</p>
                                        </div>
                                        <div class="px-3">
                                            <p class="mb-1 h6">3rd</p>
                                            <p class="small text-muted mb-0">Year</p>
                                        </div>
                                        <div>
                                            <p class="mb-1 h6">7th</p>
                                            <p class="small text-muted mb-0">SEM</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-body p-4 text-black">
                                    <div class="accordion-item">
                                        <h2 class="accordion-header" id="flush-headingone">
                                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseone" aria-expanded="false" aria-controls="flush-collapseone">
                                                Login Details
                                            </button>
                                        </h2>
                                        <div id="flush-collapseone" class="accordion-collapse collapse" aria-labelledby="flush-headingone" data-bs-parent="#accordionFlushExample">
                                            <div class="accordion-body">
                                                <table class="table table-striped table-bordered">
                                                    <tbody>
                                                        <tr>
                                                            <th scope="col" id="col">Username</th>
                                                            <td><?php echo $row['name']; ?></td>
                                                        </tr>
                                                        <tr>
                                                            <th scope="col" id="col">Password</th>
                                                            <td><?php echo $row['password']; ?></td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div><br>
                                    <div class="accordion-item">
                                        <h2 class="accordion-header" id="flush-headingTwo">
                                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo" aria-expanded="false" aria-controls="flush-collapseTwo">
                                                General Details
                                            </button>
                                        </h2>
                                        <div id="flush-collapseTwo" class="accordion-collapse collapse" aria-labelledby="flush-headingTwo" data-bs-parent="#accordionFlushExample">
                                            <div class="accordion-body">
                                                <table class="table table-striped table-bordered">
                                                    <tbody>
                                                        <tr>
                                                            <th scope="col" id="col">Admission Date</th>
                                                            <td><?php echo $row['admission_date']; ?></td>
                                                        </tr>
                                                        <tr>
                                                            <th scope="col" id="col">Registration No.</th>
                                                            <td><?php echo $row['reg_no']; ?></td>
                                                        </tr>
                                                        <tr>
                                                            <th scope="col" id="col">Date of Birth</th>
                                                            <td><?php echo $row['dob']; ?></td>
                                                        </tr>
                                                        <tr>
                                                            <th scope="col" id="col">Blood Group</th>
                                                            <td><?php echo $row['blod_group']; ?></td>
                                                        </tr>
                                                        <tr>
                                                            <th scope="col" id="col">Gender</th>
                                                            <td><?php echo $row['gender']; ?></td>
                                                        </tr>
                                                        <tr>
                                                            <th scope="col" id="col">Nationality</th>
                                                            <td><?php echo $row['nationality']; ?></td>
                                                        </tr>
                                                        <tr>
                                                            <th scope="col" id="col">Mother Tounge</th>
                                                            <td><?php echo $row['mothertounge']; ?></td>
                                                        </tr>
                                                        <tr>
                                                            <th scope="col" id="col">(CAST)Category</th>
                                                            <td><?php echo $row['cast']; ?></td>
                                                        </tr>
                                                        <tr>
                                                            <th scope="col" id="col">Religion</th>
                                                            <td><?php echo $row['religion']; ?></td>
                                                        </tr>
                                                        <tr>
                                                            <th scope="col" id="col">Aadhaar Number</th>
                                                            <td><?php echo $row['adhar_no']; ?></td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div><br>
                                    <div class="accordion-item">
                                        <h2 class="accordion-header" id="flush-headingThree">
                                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseThree" aria-expanded="false" aria-controls="flush-collapseThree">
                                                Postal Details
                                            </button>
                                        </h2>
                                        <div id="flush-collapseThree" class="accordion-collapse collapse" aria-labelledby="flush-headingThree" data-bs-parent="#accordionFlushExample">
                                            <div class="accordion-body">
                                                <table class="table table-striped table-bordered">
                                                    <tbody>
                                                        <tr>
                                                            <th scope="col" id="col">Address</th>
                                                            <td><?php echo $row['adress']; ?></td>
                                                        </tr>
                                                        <tr>
                                                            <th scope="col" id="col">City</th>
                                                            <td><?php echo $row['city']; ?></td>
                                                        </tr>
                                                        <tr>
                                                            <th scope="col" id="col">State</th>
                                                            <td><?php echo $row['state']; ?></td>
                                                        </tr>
                                                        <tr>
                                                            <th scope="col" id="col">PIN Code</th>
                                                            <td><?php echo $row['pincode']; ?></td>
                                                        </tr>
                                                        <tr>
                                                            <th scope="col" id="col">Country</th>
                                                            <td><?php echo $row['country']; ?></td>
                                                        </tr>
                                                        <tr>
                                                            <th scope="col" id="col">Birth Place</th>
                                                            <td><?php echo $row['birth_place']; ?></td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div><br>
                                    <div class="accordion-item">
                                        <h2 class="accordion-header" id="flush-headingfour">
                                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapsefour" aria-expanded="false" aria-controls="flush-collapsefour">
                                                Parent's Details
                                            </button>
                                        </h2>
                                        <div id="flush-collapsefour" class="accordion-collapse collapse" aria-labelledby="flush-headingfour" data-bs-parent="#accordionFlushExample">
                                            <div class="accordion-body">
                                                <table class="table table-striped table-bordered">
                                                    <tbody>
                                                        <tr>
                                                            <th scope="col" id="col">Father's Name</th>
                                                            <td><?php echo $row['father_name']; ?></td>
                                                        </tr>
                                                        <tr>
                                                            <th scope="col" id="col">Mother's Name</th>
                                                            <td><?php echo $row['mother_name']; ?></td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div><br>
                                    <div class="accordion-item">
                                        <h2 class="accordion-header" id="flush-headingfive">
                                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapsefive" aria-expanded="false" aria-controls="flush-collapsefive">
                                                Contact Details
                                            </button>
                                        </h2>
                                        <div id="flush-collapsefive" class="accordion-collapse collapse" aria-labelledby="flush-headingfive" data-bs-parent="#accordionFlushExample">
                                            <div class="accordion-body">
                                                <table class="table table-striped table-bordered">
                                                    <tbody>
                                                        <tr>
                                                            <th scope="col" id="col">Phone</th>
                                                            <td><?php echo $row['contact_no']; ?></td>
                                                        </tr>
                                                        <tr>
                                                            <th scope="col" id="col">Mobile</th>
                                                            <td><?php echo $row['contact_no']; ?></td>
                                                        </tr>
                                                        <tr>
                                                            <th scope="col" id="col">E-mail</th>
                                                            <td><?php echo $row['email']; ?></td>
                                                        </tr>
                                                        <tr>
                                                            <th scope="col" id="col">Father's Contact</th>
                                                            <td><?php echo $row['father_contact_no']; ?></td>
                                                        </tr>
                                                        <tr>
                                                            <th scope="col" id="col">Mother's Contact</th>
                                                            <td><?php echo $row['mother_contact_no']; ?></td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                </div>
                </div>
        <?php
            }
        }
        ?>
    </section>

</body>


</html>