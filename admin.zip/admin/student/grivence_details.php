<?php
session_start();
include('includes/header.php');
include('student_navabr.php');
// include('includes/footer.php');

?>

<!DOCTYPE html>
<html lang="en">
<?php
require 'dbconnection.php';
if (isset($_POST['viewcomplaint'])) {
    $viewid = $_POST['viewcomplaintid'];
    $query = "SELECT * FROM `grivence_register` where complaint_no='$viewid'";
    $query_run = mysqli_query($conn, $query);
    foreach ($query_run as $row) {
?>


        <head>
            <meta charset="UTF-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>G_Details</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
            <style>
                @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700&display=swap');

                .container {
                    max-width: 700px;
                    width: 100%;
                    background-color: #fff;
                    padding: 20px 30px;
                    border-radius: 5px;
                    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.15);
                }

                .img-fluid {
                    height: 200px;
                    width: 180px;
                }

                .profile-head {
                    padding-top: 15px;
                    padding-left: 20px;
                }

                .table {
                    font-size: small;
                }

                .details,
                .table-dark {
                    text-align: center;
                }

                .outer {
                    padding-top: 30px;
                    font-size: medium;
                }
            </style>

        </head>

        <body>
            <div class="container-fluid">
                <br>
                <div class="card bg-light mb-3">
                    <div class="card-header">
                        <h3><b>> </b>Grievance Details </h3>
                    </div>
                    <div class="card-body">
                        <form>
                            <table class="table table-striped table-bordered">
                                <tbody class="outer">
                                    <tr>
                                        <th scope="row">Grievance No.</th>
                                        <td><?php echo $row['complaint_no']; ?></td>
                                        <th scope="row">Complainant Id</th>
                                        <td><?php echo $row['student_id']; ?></td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Registration Date</th>
                                        <td><?php echo $row['register_date']; ?></td>
                                        <th scope="row">Grievance Type</th>
                                        <td><?php echo $row['grivence_type']; ?></td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Category</th>
                                        <td><?php echo $row['category']; ?></td>
                                        <th scope="row">Category Description (if any)</th>
                                        <td>No</td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Nature of Grievance</th>
                                        <td colspan="5"><?php echo $row['noc']; ?></td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Grievance Details</th>
                                        <td colspan="5"><?php echo $row['grivence_details']; ?></td>
                                    </tr>
                                    <tr>
                                        <th scope="row">File (if any)</th>
                                        <td colspan="5"><?php echo $row['doucement']; ?></td>
                                    </tr>
                                    <tr>
                                        <th scope="row">Final status</th>
                                        <td colspan="5">
                                            <?php
                                            if ($row['status'] == "Closed") {
                                                echo '<p class="btn btn-success">' . $row['status'] . '</p>';
                                            } else if ($row['status'] == "Inprogress") {
                                                echo '<p class="btn btn-info">' . $row['status'] . '</p>';
                                            } else if ($row['status'] == "Rejected") {
                                                echo '<p class="btn btn-danger">' . $row['status'] . '</p>';
                                            } else {
                                                echo '<p class="btn btn-warning">Pending</p>';
                                            }

                                            ?>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </form>
                    </div>
                </div>

            </div>
        </body>
<?php
    }
}

?>

</html>




<?php

include('includes/script.php');
?>