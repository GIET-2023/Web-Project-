<?php
session_start();
include('includes/header.php');
include('student_navabr.php');
// include('includes/footer.php');

?>


<div class="container-fluid">
    <div class="container">
        <div class="content" style="margin-left:35vh ;">
            <span style="font-weight:bolder; font-size:xxx-large;color:#000000;">Profile</span>
        </div>
    </div>
    <div class="content-wrapper">
        <div class="container-fluid">
            <div class="card shadow mb-5">
                <div class="card-header py-3" style="background-color: #123456;">
                    <h6 class="m-4 font-weight-bold text-primary"><span style="font-weight:bolder; font-size:x-large;color:#7FFFD4;"></span> </h6>
                </div>
                <div class="card-body">
                    <form action="code.php" class="form-group">

                        <table class="table align-items-center mb-0" id="myTable">
                            <?php
                            require 'dbconnection.php';
                            // $query = "SELECT * FROM `student` where email=";
                            $query_run = mysqli_query($conn,"SELECT * FROM `student` where email='".$_SESSION['username']."'");
                            $count = mysqli_num_rows($query_run);
                            ?>
                            <thead>
                                <tr>
                                    <th class=" text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">ID</th>
                                    <th class=" text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">IMAGE</th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">NAME</th>
                                    <th class=" text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Registration No</th>
                                    <th class="text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 ">DEPARTMENT NAME</th>
                                    <th class=" text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">MOBILE</th>
                                    <th class=" text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Email</th>
                                    <th class=" text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Parents Name</th>
                                    <th class=" text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Parents Conatct</th>
                                    <th class=" text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Stream</th>
                                    <th class=" text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Password</th>
                                    <th class=" text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Usertype</th>
                                    <th class=" text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Status</th>
                                    <th class=" text-uppercase text-secondary text-xxs font-weight-bolder opacity-7">Edit</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                if ($count > 0) {
                                    $idno = 0;
                                    while ($row = mysqli_fetch_assoc($query_run)) {
                                        $idno = $idno + 1;
                                ?>

                                        <tr>
                                            <td><?php echo $idno; ?></td>
                                            <td><?php echo  '<img src="../userimage/' . $row['image'] . '" alt="" height="50px" width="50px" style="border-radius:50% ;">' ?></td>
                                            <td><?php echo $row['name']; ?></td>
                                            <td><?php echo $row['Reg_no']; ?></td>
                                            <td><?php echo $row['department']; ?></td>
                                            <td><?php echo $row['mobile']; ?></td>
                                            <td><?php echo $row['email']; ?></td>
                                            <td><?php echo $row['parents_name']; ?></td>
                                            <td><?php echo $row['parents_mobileno']; ?></td>
                                            <td><?php echo $row['stream']; ?></td>
                                            <td><?php echo $row['password']; ?></td>
                                            <td><?php echo $row['usertype']; ?></td>
                                            <td><?php echo $row['status']; ?></td>
                                            <td>

                                                <form action="updatestudent.php" method="POST">
                                                    <input type="hidden" name="studentid" value="<?php echo $row['id'] ?>">
                                                    <button type="submit" class="btn btn-success" name="addstudent">Edit</button>
                                                </form>
                                            </td>
                                        </tr>

                                <?php
                                    }
                                }
                                ?>
                            </tbody>

                        </table>
                    </form>
                </div>
            </div>
        </div>
    </div>

</div>








<?php

include ('includes/script.php');
?>
   