<?php
session_start();
include('includes/header.php');
include('student_navabr.php');
// include('includes/footer.php');

?>
<div class="container-fluid">

<div class="content-wrapper">
    <div class="container-fluid">
        
        <div class="card shadow mb-5">
            <div class="card-header py-3" style="background-color: #123456;">
                <h6 class="m-4 font-weight-bold text-primary"><span style="font-weight:bolder; font-size:x-large;color:#7FFFD4;">Grivence history</span> </h6>
            </div>
            <div class="card-body">

                <table class="table table-bordered" width="100%" cellspacing="0" id="myTable">
                    <?php
                        require 'dbconnection.php';
                        if(isset($_POST['vvewcomplaint'])){
                            $cid = $_POST['vviewcomplaintid'];
                            $query = "SELECT * FROM `grivence_register` where student_id='$cid' AND (status='Inprogress' OR status='Pending')";
                            $query_run = mysqli_query($conn,$query);
                            $query_run_num = mysqli_num_rows($query_run);
                        }

                        ?>
                   

                    <thead>
                        <tr>
                            <th>Complaint No</th>
                            <th>Reg Date</th>
                            <th>Last update date</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if($query_run_num>0){
                            $slno =0;
                            while($row = mysqli_fetch_assoc($query_run)){
                                $slno=$slno+1;
                                ?>
                               

                                <tr>
                                    <td><?php echo $slno; ?></td>
                                    <td><?php echo $row['register_date']; ?></td>
                                    <td><?php echo $row['update_date']; ?></td>
                                    <td><?php 
                                     if($row['status']=="Closed"){
                                        echo '<p class="btn btn-success">'.$row['status'].'</p>';
                                     }
                                     else if($row['status']=="Inprogress"){
                                        echo '<p class="btn btn-info">'.$row['status'].'</p>';
                                     }else if($row['status']=="Rejected"){
                                        echo '<p class="btn btn-danger">'.$row['status'].'</p>';
                                     }
                                     else{
                                        echo '<p class="btn btn-warning">Pending</p>';
                                     }
                                    
                                    ?></td>
                                    <td>
                                        <form action="grivence_details.php" method="POST">
                                            <input type="hidden" name="viewcomplaintid" value="<?php echo $row['complaint_no']; ?>">
                                            <button type="submit" name="viewcomplaint" class="btn btn-primary">View Details</button>
                                        </form>
                                    </td>
                                </tr>
                                <?php
                            }
                        }
                        ?>
                        
                    </tbody>

                </table>

            </div>
        </div>
    </div>
</div>

</div>




<?php

include('includes/script.php');
?>