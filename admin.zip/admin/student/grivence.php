<?php
session_start();
include('includes/header.php');
include('student_navabr.php');
// include('includes/footer.php');

?>
<div class="container-fluid">

    <div class="content-wrapper">
        <div class="container-fluid">
            <div class="card shadow mb-5">
                <div class="card-header py-3" style="background-color: #123456;">
                    <h6 class="m-4 font-weight-bold text-primary"><span style="font-weight:bolder; font-size:x-large;color:#7FFFD4;">New Complaint</span>
                        <div class="float-right">
                            <a href="grivence_complaint.php" class="btn btn-success">Lodge </a>
                        </div>
                    </h6>
                </div>

            </div>

        </div>
        <div class="container-fluid">
            <div class="card shadow mb-5">
                <div class="card-header py-3" style="background-color: #123456;">
                    <h6 class="m-4 font-weight-bold text-primary"><span style="font-weight:bolder; font-size:x-large;color:#7FFFD4;">Recent Complaint</span>
                        <?php
                        require 'dbconnection.php';
                        $query = "SELECT * FROM `student` where  reg_no='" . $_SESSION['studentusername'] . "'";
                        $query_run = mysqli_query($conn, $query);
                        $num_query = mysqli_num_rows($query_run);
                        ?>
                        <div class="float-right">
                            <?php
                            if ($num_query > 0) {
                                while ($row = mysqli_fetch_assoc($query_run)) {
                            ?>
                                    <form action="g_recent_.php" method="post">  
                                        <input type="hidden" name="vviewcomplaintid" value="<?php echo $row['id']; ?>">
                                        <button class="btn btn-success pl-3 pr-3" type="submit" name="vvewcomplaint">View </button>
                                    </form>
                            <?php
                                }
                            }
                            ?>
                        </div>
                    </h6>
                </div>

            </div>

        </div>
        <div class="container-fluid">
            <div class="card shadow mb-5">
                <div class="card-header py-3" style="background-color: #123456;">
                    <h6 class="m-4 font-weight-bold text-primary"><span style="font-weight:bolder; font-size:x-large;color:#7FFFD4;">Complaint History</span>
                        <?php
                        require 'dbconnection.php';
                        $query = "SELECT * FROM `student` where  reg_no='" . $_SESSION['studentusername'] . "'";
                        $query_run = mysqli_query($conn, $query);
                        $num_query = mysqli_num_rows($query_run);
                        ?>
                        <div class="float-right">
                            <?php
                            if ($num_query > 0) {
                                while ($row = mysqli_fetch_assoc($query_run)) {
                            ?>
                                    <form action="grivence_history.php" method="post">  
                                        <input type="hidden" name="viewcomplaintid" value="<?php echo $row['id']; ?>">
                                        <button class="btn btn-success pl-3 pr-3" type="submit" name="vewcomplaint">View</button>
                                    </form>
                            <?php
                                }
                            }
                            ?>
                        </div>
                    </h6>
                </div>

            </div>

        </div>
        
    </div>

</div>




<?php

include('includes/script.php');
?>